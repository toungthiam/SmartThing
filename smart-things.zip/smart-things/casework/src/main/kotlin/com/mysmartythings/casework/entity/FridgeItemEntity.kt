package com.mysmartythings.casework.entity

import com.mysmartythings.casework.model.Category
import com.mysmartythings.casework.model.FridgeItem
import javax.persistence.*
import javax.validation.constraints.NotNull

/**
 * Fridge item. what is in the fridge?
 */
@Entity
class FridgeItemEntity (@NotNull
                        @Column(name="FRIDGE_ENTITY_SERIAL_NUMBER")
                        var serialNumber: String,
                        var name: String,
                        @Enumerated(EnumType.STRING)
                        var category: Category,
                        var description: String,
                        var numberOfUnit: Int,
                        @Id
                        @GeneratedValue
                        var id: Long? = null)

fun FridgeItemEntity.toFridgeItem(): FridgeItem {
    return FridgeItem(this.name, this.category, this.description, this.numberOfUnit)
}
