package com.mysmartythings.casework.entity

import org.springframework.data.jpa.repository.Query
import org.springframework.data.repository.CrudRepository
import org.springframework.data.repository.query.Param
import org.springframework.lang.Nullable
import org.springframework.stereotype.Repository

/**
 * Repository for the Fridge domain model
 * help persists it
 */
@Repository
interface FridgeRepository : CrudRepository<FridgeEntity, String>  {
    @Nullable
    @Query("SELECT SUM(fi.numberOfUnit) FROM FridgeItemEntity fi WHERE fi.serialNumber = :serialNumber AND "+
            "fi.category = 'BEVERAGE' AND fi.name = 'can of soda'")
    fun countNumberOfCansOfSoda(@Param("serialNumber") serialNumber: String): Long?
}
