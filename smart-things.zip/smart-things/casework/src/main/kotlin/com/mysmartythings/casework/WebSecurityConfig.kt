package com.mysmartythings.casework

import org.springframework.context.annotation.Configuration
import org.springframework.data.jpa.repository.config.EnableJpaRepositories
import org.springframework.security.config.annotation.web.builders.HttpSecurity
import org.springframework.security.config.annotation.web.builders.WebSecurity
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer
import springfox.documentation.swagger2.annotations.EnableSwagger2

/**
 * Describe our security (authorization) setup service for the app.
 *
 *
 *
 * Override the WebSecurityConfigurerAdapter contains the protected paths
 * but also, not protected documentation resources
 *
 *
 *
 * @see WebSecurityConfigurerAdapter
 *
 *
 * @author Alioune Thiam
 */
@Configuration
@EnableJpaRepositories
@EnableWebSecurity
@EnableResourceServer
@EnableSwagger2
class WebSecurityConfig : WebSecurityConfigurerAdapter() {
    override fun configure(http: HttpSecurity) {
        http
                .authorizeRequests()
                .antMatchers("/v2/api-docs*", "/swagger-ui.html", "/actuator/*", "/h2-console", "/h2-console/*").permitAll()
                .anyRequest().authenticated()
                .and()
                .csrf().disable()
    }

    override fun configure(webSecurity: WebSecurity) { //disable the parent directory access
        webSecurity.ignoring()
                .antMatchers("../*")
    }
}
