package com.mysmartythings.casework.service

import com.mysmartythings.casework.entity.*
import com.mysmartythings.casework.model.Fridge
import com.mysmartythings.casework.model.FridgeItem
import com.mysmartythings.casework.model.FridgeItem.Companion.MAX_NUMBER_CANS_OF_SODA
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.data.repository.findByIdOrNull
import org.springframework.stereotype.Service
import javax.transaction.Transactional
/**
 * Fridge Item service class.. main application business logic is here
 *
 */
@Service
class FridgeItemService(@Autowired val fridgeItemRepository: FridgeItemRepository,
                        @Autowired val fridgeRepository: FridgeRepository,
                        val validator: RecordValidator =
                                MaximumNumberOfCansOfSodaConstraintValidator(MAX_NUMBER_CANS_OF_SODA,
                                                                            fridgeRepository)) {
    @Transactional
    fun addToFridge(fridgeSerialNumber: String, items: List<FridgeItem>): Fridge {
        var dbFridgeEntity = fridgeRepository.findById(fridgeSerialNumber).orElseThrow{InvalidRequest("no such fridge")}
        val newList: List<FridgeItemEntity> = dbFridgeEntity.items.plus(items.map { toFridgeItemEntity(fridgeSerialNumber, it) })
        val newFridgeEntity = FridgeEntity(dbFridgeEntity.serialNumber, dbFridgeEntity.modelNumber, dbFridgeEntity.manufacturer,
                                           dbFridgeEntity.name, newList)
        val consolidatedFridge = newFridgeEntity.toFridge()
        if (validator.isValid(consolidatedFridge)) {
            fridgeItemRepository.saveAll(FridgeEntity.from(consolidatedFridge).items)
            return fridgeRepository.findByIdOrNull(fridgeSerialNumber)?.toFridge() ?:
                    throw InvalidRequest("Server error")
        }
        throw InvalidRequest("To many cans of soda")
    }

    @Transactional
    fun deleteItem(serialNumber: String, name: String) {
        fridgeItemRepository.deleteByName(serialNumber, name)
    }

    data class InvalidRequest(val msg: String): Throwable(msg)

    fun toFridgeItemEntity(serialNumber: String, fridgeItem: FridgeItem): FridgeItemEntity {
        return FridgeItemEntity(serialNumber, fridgeItem.name,  fridgeItem.category,
                                fridgeItem.description, fridgeItem.numberOfUnit)
    }
}

