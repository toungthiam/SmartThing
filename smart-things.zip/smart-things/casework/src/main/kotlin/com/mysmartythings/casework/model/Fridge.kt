package com.mysmartythings.casework.model

import com.mysmartythings.casework.entity.FridgeEntity
import io.swagger.annotations.ApiModel

/**
 * Fridge item...
 * Very simple model here but it is easy to see it
 * grow a little bit.. can we delete a fridge full of items ?
 */
@ApiModel("The fridge container class of the API.")
data class Fridge( val serialNumber: String,
                   val modelNumber: String,
                   val manufacturer: String,
                   val name: String = "$manufacturer $modelNumber $serialNumber",
                   val items: List<FridgeItem>) {
    constructor(fridge: FridgeEntity) :
            this(fridge.serialNumber, fridge.modelNumber, fridge.manufacturer, fridge.name,
                    fridge.items.map { FridgeItem(it.name, it.category, it.description, it.numberOfUnit) })
}
