package com.mysmartythings.casework.service

import com.mysmartythings.casework.entity.FridgeEntity
import com.mysmartythings.casework.entity.FridgeRepository
import com.mysmartythings.casework.entity.toFridge
import com.mysmartythings.casework.model.Fridge
import com.mysmartythings.casework.model.FridgeItem
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.data.repository.findByIdOrNull
import org.springframework.http.HttpStatus
import org.springframework.stereotype.Service
import org.springframework.web.bind.annotation.ResponseStatus
import javax.transaction.Transactional

/**
 * Fridge service class.. main application business logic is here
 *
 */
@Service
class FridgeService(@Autowired val fridgeRepository: FridgeRepository,
                    val validator: RecordValidator =
                            MaximumNumberOfCansOfSodaConstraintValidator(FridgeItem.MAX_NUMBER_CANS_OF_SODA,
                                                                         fridgeRepository)) {
    fun findById(sn: String): Fridge? {
        return fridgeRepository.findByIdOrNull(sn)?.let{it.toFridge()}
    }

    @Transactional
    fun saveRecord(fridge: Fridge): Fridge {
        return if (validator.isValid(fridge)) {
            fridgeRepository.save(FridgeEntity.from(fridge)).toFridge()
        } else {
            throw PersistentErrorException("Invalid value")
        }
    }

    @Transactional
    fun deleteFridge(serialNumber: String) {
        val fridgeEntity = fridgeRepository.findByIdOrNull(serialNumber)
        fridgeEntity?.let {
            return if (it.items.isNullOrEmpty()) {
                fridgeRepository.deleteById(serialNumber)
            } else  throw PersistentErrorException("Fridge is not empty")
        } ?: throw PersistentErrorException("Invalid request")
    }
}

@ResponseStatus(code = HttpStatus.BAD_REQUEST)
data class PersistentErrorException(val msg: String): Throwable(msg)
