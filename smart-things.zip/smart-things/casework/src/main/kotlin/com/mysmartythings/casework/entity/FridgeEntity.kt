package com.mysmartythings.casework.entity

import com.mysmartythings.casework.model.Category
import com.mysmartythings.casework.model.Fridge
import javax.persistence.*
import javax.validation.constraints.NotNull

/**
 * Fridge item...
 * Very simple model here but it is easy to see it
 * grow a little bit.. can we delete a fridge full of items ?
 */
@Entity
class FridgeEntity(@Id
                   @NotNull
                   val serialNumber: String,
                   val modelNumber: String,
                   val manufacturer: String,
                   val name: String,
                   @OneToMany(cascade = [CascadeType.ALL], fetch= FetchType.EAGER)
                   @JoinColumn(name = "FRIDGE_ENTITY_SERIAL_NUMBER")
                   val items: List<FridgeItemEntity>) {
    companion object {
        /**
         * Some logic here..
         * We need to group the items..
         * It's soda, quantity 5 even if the user submits soda, 2 and soda, 3
         */
        fun from(fridge: Fridge): FridgeEntity {
            return FridgeEntity(fridge.serialNumber, fridge.modelNumber, fridge.manufacturer, fridge.name,
                    fridge.items.groupingBy { item -> ItemGroupingKey(item.category, item.name) }
                            .fold(FridgeItemEntity(fridge.serialNumber, "", Category.BEVERAGE, "", 0))
                            { acc, fridgeItem -> FridgeItemEntity(fridge.serialNumber, fridgeItem.name,
                                    fridgeItem.category, fridgeItem.description,
                                    acc.numberOfUnit + fridgeItem.numberOfUnit) }.values.toList()
            )
        }
    }
}

fun FridgeEntity.toFridge(): Fridge {
    return Fridge(this.serialNumber, this.modelNumber, this.manufacturer,
                  this.name, this.items.map { it.toFridgeItem() })
}

data class ItemGroupingKey(val category: Category,
                           val name: String)
