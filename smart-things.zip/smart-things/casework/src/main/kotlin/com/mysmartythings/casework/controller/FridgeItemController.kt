package com.mysmartythings.casework.controller

import com.mysmartythings.casework.model.Fridge
import com.mysmartythings.casework.model.FridgeItem
import com.mysmartythings.casework.service.FridgeItemService
import org.springframework.http.HttpStatus
import org.springframework.web.bind.annotation.*
import org.springframework.web.server.ResponseStatusException


/**
 * Rest controller for the fridge items of the application
 *
 *
 * @author Alioune_Thiam
 */
@RestController
@RequestMapping("/v1/fridges/{serialNumber}/items")
open class FridgeItemController(val fridgeItemService: FridgeItemService) {
    @PostMapping("/")
    fun addItemsToFridge(@RequestBody fridgeItems: List<FridgeItem>,
                         @PathVariable("serialNumber") serialNumber: String): Fridge {
        try {
            return fridgeItemService.addToFridge(serialNumber, fridgeItems)
        } catch(e: FridgeItemService.InvalidRequest) {
            throw ResponseStatusException(HttpStatus.NOT_FOUND, e.msg)
        }
    }

    @DeleteMapping("/{name}")
    fun deleteFridgeItem(@PathVariable("serialNumber") serialNumber: String,
                         @PathVariable("name") name: String) : HttpStatus {
        fridgeItemService.deleteItem(serialNumber, name)
        return HttpStatus.NO_CONTENT
    }
}
