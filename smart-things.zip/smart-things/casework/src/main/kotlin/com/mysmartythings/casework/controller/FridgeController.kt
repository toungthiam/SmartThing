package com.mysmartythings.casework.controller

import com.mysmartythings.casework.model.Fridge
import com.mysmartythings.casework.service.FridgeService
import org.springframework.http.HttpStatus
import org.springframework.web.bind.annotation.*
import org.springframework.web.server.ResponseStatusException

/**
 * Rest controller for the application
 *
 * @author Alioune_Thiam
 */
@RestController
@RequestMapping("/v1/fridges")
open class FridgeController(val fridgeService: FridgeService) {
    @GetMapping("/{serialNumber}")
    fun whatsInTheFridge(@PathVariable("serialNumber") serialNumber: String): Fridge {
        return fridgeService.findById(serialNumber) ?: throw ResponseStatusException(HttpStatus.NOT_FOUND, serialNumber)
    }

    @PostMapping("/")
    fun registerFridge(@RequestBody fridge: Fridge): Fridge {
        return fridgeService.saveRecord(fridge)
    }

    @DeleteMapping("/{serialNumber}")
    fun deregisterFridge(@PathVariable("serialNumber") serialNumber: String): HttpStatus {
        fridgeService.deleteFridge(serialNumber)
        return HttpStatus.NO_CONTENT;
    }
}
