package com.mysmartythings.casework.entity

import org.springframework.data.jpa.repository.Modifying
import org.springframework.data.jpa.repository.Query
import org.springframework.data.repository.CrudRepository
import org.springframework.data.repository.query.Param
import org.springframework.stereotype.Repository
import java.util.*

/**
 * Repository for the FridgeItem domain model
 * help persists it
 */
@Repository
interface FridgeItemRepository  : CrudRepository<FridgeItemEntity, String> {
    @Modifying
    @Query("DELETE FROM FridgeItemEntity fi WHERE fi.serialNumber = :fridge AND fi.name = :name")
    fun deleteByName(@Param("fridge") fridge: String,
                     @Param("name") name: String)
}
