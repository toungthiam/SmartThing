package com.mysmartythings.casework.service
import com.mysmartythings.casework.entity.FridgeRepository
import com.mysmartythings.casework.model.Category
import com.mysmartythings.casework.model.Fridge
import com.mysmartythings.casework.model.FridgeItem
import com.mysmartythings.casework.model.FridgeItem.Companion.MAX_NUMBER_CANS_OF_SODA
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component

/**
 * Constraint policy.. example no more than 12 cans of soda
 *
 */
@Component
class MaximumNumberOfCansOfSodaConstraintValidator(private val maxNumberOfCanOfSoda: Int = MAX_NUMBER_CANS_OF_SODA,
                                                   @Autowired private val fridgeRepository: FridgeRepository)
        : RecordValidator {
    override fun isValid(value: Fridge): Boolean {
        val numberOfCansToAdd: Long = value.items
                                .filter { it.category == Category.BEVERAGE &&
                                          it.name == FridgeItem.CAN_OF_SODA_NAME }
                                .fold (0L) {acc, item -> item.numberOfUnit + acc}
        return numberOfCansToAdd +
                fridgeRepository.countNumberOfCansOfSoda(value.serialNumber) <= maxNumberOfCanOfSoda
    }
}

private operator fun Long.plus(countNumberOfCansOfSoda: Long?): Long {
    return countNumberOfCansOfSoda ?: 0
}
