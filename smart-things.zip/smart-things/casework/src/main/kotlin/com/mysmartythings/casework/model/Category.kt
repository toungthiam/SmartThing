package com.mysmartythings.casework.model

import io.swagger.annotations.ApiModel

/**
 * Category of Item in the fridge
 * Writing this starting giving me idea about
 * creating sections and maybe a more granular details
 * Alcohol vs non alcohol for beverage, I think some would like
 * to day hey fridge is there any beer in there ona  friday
 * evening on way from home to work
 *
 */

@ApiModel("Available category for the fridge item.")
enum class Category(val stringValue: String) {
    FOOD("Food"),
    BEVERAGE( "Beverage"),
    SNACK ("Snack")
}
