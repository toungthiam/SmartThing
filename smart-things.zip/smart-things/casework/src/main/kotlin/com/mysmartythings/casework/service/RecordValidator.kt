package com.mysmartythings.casework.service

import com.mysmartythings.casework.model.Fridge

/**
 * Policy interface
 *
 */
interface RecordValidator {
    fun isValid(fridge: Fridge): Boolean
}
