package com.mysmartythings.casework.model

import io.swagger.annotations.ApiModel

/**
 * Fridge item. what is in the fridge?
 */
@ApiModel("The fridge item model.")
data class FridgeItem (val name: String,
                       val category: Category,
                       val description: String,
                       val numberOfUnit: Int) {
    companion object {
        const val CAN_OF_SODA_NAME = "can of soda"
        const val MAX_NUMBER_CANS_OF_SODA: Int = 12
    }
}
