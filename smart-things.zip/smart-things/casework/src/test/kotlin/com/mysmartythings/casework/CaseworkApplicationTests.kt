package com.mysmartythings.casework

import com.mysmartythings.casework.model.Fridge
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.boot.test.web.client.TestRestTemplate
import org.springframework.boot.web.server.LocalServerPort
import org.springframework.http.*
import org.springframework.util.LinkedMultiValueMap
import org.springframework.util.MultiValueMap

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class CaseworkApplicationTests(@Autowired val restTemplate: TestRestTemplate) {

	@LocalServerPort
	private val port = 0

	private val accessToken = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ._MeAkTfikk3lBHXD2g3PukM8hRmd02go06nX1V6KliY"

	@Test
	fun `we can register add a fridge`() {
		val fridgeToAdd = Fridge("SN93000", "ModelNumber", "Whirlpool", "Main Fridge", listOf())
		val entity: HttpEntity<*> = getEntityWithHeaders(fridgeToAdd)

		val fridgeResponse: ResponseEntity<Fridge> = this.restTemplate.exchange(getUrl(),
				HttpMethod.POST, entity, Fridge::class.java)

		assertThat(fridgeResponse.statusCode).isEqualTo(HttpStatus.OK)
	}

	private fun getUrl(): String = "http://localhost:$port/v1/fridges/"

	private fun getEntityWithHeaders(fridgeToAdd: Fridge): HttpEntity<*> {
		val headers: MultiValueMap<String, String> = LinkedMultiValueMap()
		headers[HttpHeaders.AUTHORIZATION] = listOf("Bearer $accessToken")
		headers[HttpHeaders.ACCEPT] = listOf(MediaType.APPLICATION_JSON_VALUE)
		headers[HttpHeaders.CONTENT_TYPE] = MediaType.APPLICATION_JSON_VALUE
		return HttpEntity<Any>(fridgeToAdd, headers)
	}
}
