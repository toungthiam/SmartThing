package com.mysmartythings.casework.entity

import com.mysmartythings.casework.model.Category
import org.springframework.data.repository.findByIdOrNull

import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager

@DataJpaTest
class FridgeRepositoryUnitTest  @Autowired constructor(
        val entityManager: TestEntityManager,
        val fridgeRepository: FridgeRepository,
        val fridgeItemRepository: FridgeItemRepository) {

    @Test
    fun `When findByIdOrNull then return Fridge`() {
        val fridgeEntity = FridgeEntity("SN123", "MA", "GE", "My Fridge", listOf() )
        entityManager.persist(fridgeEntity)
        entityManager.flush()
        val found = fridgeRepository.findByIdOrNull(fridgeEntity.serialNumber)
        assertThat(found).isEqualTo(fridgeEntity)
    }

    @Test
    fun `When countNumberOfCansOfSoda then return correct value`() {
        val serialNumber = "SN123"
        val fridgeItemEntity = FridgeItemEntity(serialNumber, "can of soda", Category.BEVERAGE, "Can of Soda", 6)
        val fridgeItemPepsi = FridgeItemEntity(serialNumber, "can of soda",Category.BEVERAGE, "Can of Pepsi Soda", 7)
        val fridgeEntity = FridgeEntity(serialNumber, "MA", "GE", "My Fridge", listOf(fridgeItemEntity, fridgeItemPepsi) )
        entityManager.persist(fridgeEntity)
        entityManager.flush()
        val number = fridgeRepository.countNumberOfCansOfSoda(fridgeEntity.serialNumber)
        assertThat(number).isEqualTo(13L)
    }
}