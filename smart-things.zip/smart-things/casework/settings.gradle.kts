pluginManagement {
    repositories {
        gradlePluginPortal()
    }
}
rootProject.name = "casework"
