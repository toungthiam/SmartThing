import org.jetbrains.kotlin.gradle.tasks.KotlinCompile

repositories {
	mavenCentral()
	jcenter()
}

plugins {
	id("org.springframework.boot") version "2.2.1.RELEASE"
	id("io.spring.dependency-management") version "1.0.8.RELEASE"
	id("com.palantir.docker") version "0.22.1"
	id("io.gitlab.arturbosch.detekt") version "1.2.1"
	id("org.jetbrains.kotlin.plugin.noarg") version "1.3.60"
	jacoco
	kotlin("jvm") version "1.3.60"
	kotlin("plugin.spring") version "1.3.60"
	kotlin("plugin.jpa") version "1.3.60"
	kotlin("plugin.allopen") version "1.3.60"
	kotlin("kapt") version "1.3.60"
}

group = "com.mysmartythings"
val appVersion = "0.0.1"
version = appVersion
java.sourceCompatibility = JavaVersion.VERSION_11
java.targetCompatibility = JavaVersion.VERSION_11

dependencies {
	implementation("org.springframework.boot:spring-boot-starter-web")
	implementation("org.springframework.boot:spring-boot-starter-actuator")
	implementation("org.springframework.boot:spring-boot-starter-data-jpa")
	implementation("org.springframework.boot:spring-boot-starter-security")
	implementation("org.springframework.boot:spring-boot-starter-oauth2-resource-server")
	implementation("org.springframework.security.oauth.boot:spring-security-oauth2-autoconfigure:2.2.0.RELEASE")
	implementation("org.springframework.security:spring-security-jwt:1.0.10.RELEASE")
	implementation("io.springfox:springfox-swagger2:2.9.2")
	implementation("io.springfox:springfox-swagger-ui:2.9.2")
	implementation("com.fasterxml.jackson.module:jackson-module-kotlin")
	implementation("org.jetbrains.kotlin:kotlin-reflect")
	implementation("org.jetbrains.kotlin:kotlin-stdlib-jdk8")
	implementation("org.jetbrains.kotlinx:kotlinx-html-jvm:0.6.12")
	runtimeOnly("com.h2database:h2")
	testImplementation("org.springframework.boot:spring-boot-starter-test") {
		exclude(module = "junit")
		exclude(module = "mockito-core")
	}
	testImplementation("org.junit.jupiter:junit-jupiter-api")
	testRuntimeOnly("org.junit.jupiter:junit-jupiter-engine")
	testImplementation("com.ninja-squad:springmockk:1.1.3")

	kapt("org.springframework.boot:spring-boot-configuration-processor")
	testImplementation("org.springframework.boot:spring-boot-starter-test") {
		exclude(group = "org.junit.vintage", module = "junit-vintage-engine")
		exclude(module = "mockito-core")
	}
	testImplementation("org.junit.jupiter:junit-jupiter-api")
	testRuntimeOnly("org.junit.jupiter:junit-jupiter-engine")
	testImplementation("com.ninja-squad:springmockk:1.1.3")

	testImplementation("org.springframework.security:spring-security-test")
}

docker {
    name = "athiam/mysmartythings:${appVersion}"
    buildArgs(mapOf("BUILD_VERSION" to appVersion, "BUILD_DIR" to "build"))
	copySpec.from("build").into("build")
	setDockerfile(file("Dockerfile"))
}

detekt {
	toolVersion = "1.2.1"
	input = files(
			"src/main/kotlin",
			"src/test/kotlin"
	)
}

jacoco {
	toolVersion = "0.8.2"
}

tasks {
	jacocoTestCoverageVerification {
		violationRules {
			rule { limit { minimum = BigDecimal.valueOf(0.1) } }
		}
	}
	check {
		dependsOn(jacocoTestCoverageVerification)
	}
}

tasks.withType<Test> {
	useJUnitPlatform()
}

tasks.withType<KotlinCompile> {
	kotlinOptions {
		freeCompilerArgs = listOf("-Xjsr305=strict")
		jvmTarget = "1.8"
	}
}

allOpen {
	annotation("javax.persistence.Entity")
}
